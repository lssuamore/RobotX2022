#ifndef HELLO_GUI_H
#define HELLO_GUI_H

#include <QWidget>
#include <QColor>
#include <ros/ros.h>
#include <qtimer.h>
#include <std_msgs/String.h>
#include <std_msgs/Float64.h>
#include "nav_msgs/Odometry.h"
#include "sensor_msgs/Imu.h"
#include "sensor_msgs/NavSatFix.h"
//Heartbeat Code Includes and Constants
#include <arpa/inet.h> // inet_addr()
#include <netdb.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h> // bzero()
#include <sys/socket.h>
#include <unistd.h> // read(), write(), close()
#define MAX 256
#define SA struct sockaddr
#define PORT 8080
#define IP "127.0.0.1"
#define MSG "RXHRB,111221,161229,21.31198,N,157.88972,W,ROBOT,2,2"

namespace Ui {
class HelloGui;
}


class HelloGui : public QWidget
{
  Q_OBJECT

public:
  explicit HelloGui(QWidget *parent = nullptr);
  ~HelloGui();
  void USV_latitude(const std_msgs::String::ConstPtr& USV_lat);
  void USV_longitude(const std_msgs::String::ConstPtr& USV_lon);
//  void UAV_latitude(const std_msgs::String::ConstPtr& UAV_lat);
//  void UAV_longitude(const std_msgs::String::ConstPtr& UAV_lon);
  void x_usv_N(const std_msgs::String::ConstPtr& USV_X_NE);
  void y_usv_N(const std_msgs::String::ConstPtr& USV_Y_NE);
  void rcolor(const std_msgs::String::ConstPtr& recolor);
  void gcolor(const std_msgs::String::ConstPtr& grcolor);
  void bcolor(const std_msgs::String::ConstPtr& blcolor);
  void USV_Heading(const std_msgs::String::ConstPtr& USV_msg);
  void UAV_Heading(const std_msgs::String::ConstPtr& UAV_msg);
  void AMS_mode(const std_msgs::String::ConstPtr& mod);
  void Color_Light (const std_msgs::String::ConstPtr& light);
  void Animal_Color_Light (const std_msgs::String::ConstPtr& putrycolors);
  void Tech_Sever_Ip(const std_msgs::String::ConstPtr& server);
  void Team_INfo(const std_msgs::String::ConstPtr& info);
  void PORt(const std_msgs::String::ConstPtr& por);

  void heartbeat();
public slots:
    void spinOnce();


//private slots:
//    void onColorChanged();


private slots:
    void on_Server_IP_Input_Box_released();

private:
    Ui::HelloGui *ui;
//    QString *ip;
    QTimer *ros_timer;


    ros::NodeHandlePtr nh_;

    ros::Subscriber USV_latitude_sub_;
    ros::Subscriber USV_longitude_sub_;
//  ros::Subscriber UAV_latitude_sub_;
//  ros::Subscriber UAV_longitude_sub_;
    ros::Subscriber x_usv_NED_sub_;
    ros::Subscriber y_usv_NED_sub_;
    ros::Subscriber AMS_Mode_sub_;
    ros::Subscriber USV_heading_sub_;
    ros::Subscriber UAV_heading_sub_;
    ros::Subscriber Color_Light_sub_;
    ros::Subscriber Animal_Color_Light_sub_;
    ros::Subscriber gps_pos_sub_;
    ros::Subscriber nav_NED_sub_;
    ros::Subscriber imu_sub;
    ros::Subscriber obj_rec_sub_;
    ros::Subscriber CC_animals_ned_sub_;
    ros::Subscriber Tech_Sever_Ip_sub_;
//    ros::Subscriber AMS_status_sub;
    //ros::Subscriber imu_sub; //for UAV need
//    ros::Subscriber color_sub_;
//    ros::Publisher  hello_pub_;
    ros::Publisher Server_IP_pub_;
    ros::Publisher Team_Info_pub_;
    ros::Publisher Port_pub_;

};



/*open a tcp socket and send an NMEA string*/
class heartbeat_sock
{
private:
    char ip[MAX];
    char port[MAX];
    int sockfd, connfd;
public:
    //open socket  ip (v4 format), port
  heartbeat_sock(const char [], const int);
    //closes socket
  ~heartbeat_sock();
    //send NMEA string packet; sockfd, message to send
    int send(const char *);
};

  #endif // HELLO_GUI_H
