//talker will be coming from the code already made

#include "ros/ros.h"
#include "std_msgs/String.h"
#include "nav_msgs/Odometry.h"
#include "sensor_msgs/Imu.h"
#include <sstream>
#include "sensor_msgs/NavSatFix.h"		// message type of lat and long coordinates given by the GPS
//#include "jetson/AMS_state.h"
#include "geometry_msgs/PointStamped.h"
#define PI 3.14159265

//Task 5
std::string Object;  // string array to hold the names of the objects from the zed2i
float x_object_NED[9], y_object_NED[9];  // arrays to hold animal locations
std::string Cod_Seq, Cod_Seq_Temp = "Nothing";
int cnt = 0;
int black = 0;
//Task 4
std::string Animal, Animal_Temp;  // string array to hold the names of the animals
char Animal_str = {}; // String to send animals for heartbeat
int animal_qty = 0;


//Other variables
double latitude_USV,longitude_USV,altitude, x_NED_USV, y_NED_USV, latitude_UAV,longitude_UAV;
int redcolor,greencolor,bluecolor;
void gps_processor(const sensor_msgs::NavSatFix::ConstPtr& gps_msg)
{
  latitude_USV = gps_msg->latitude; //sets latitude from gps
  longitude_USV = gps_msg->longitude; //sets longitude from gps
  altitude = gps_msg->altitude; //sets altitude rom gps
} // END OF gps_processor()

void pose_update(const nav_msgs::Odometry::ConstPtr& odom){
  x_NED_USV = odom->pose.pose.position.x;
  y_NED_USV = odom->pose.pose.position.y;
  ROS_INFO("%d, %d\n",x_NED_USV,y_NED_USV);
}

float q1, q2, q3, q0;	// Sparton imu quarternion
float phi, theta, psi;	// conversion to radians
float phiNED, thetaNED, psiNED;
float omega_x, omega_y, omega_z;

void imu_processor(const sensor_msgs::Imu::ConstPtr& imu_msg)
{
 // gather orientation quaternion
 q1 = imu_msg->orientation.x;
 q2 = imu_msg->orientation.y;
 q3 = imu_msg->orientation.z;
 q0 = imu_msg->orientation.w;

 // gather body-fixed angular velocity
 omega_x = imu_msg->angular_velocity.x;
 omega_y = imu_msg->angular_velocity.y;
 omega_z = imu_msg->angular_velocity.z;

 //converts to radians
 psi = atan2((2.0*(q3*q0 + q1*q2)) , (1.0 - 2.0*(pow(q2,2.0) + pow(q3,2.0)))); // orientation off x-axis
 // Convert the orientation to NED from ENU
 psiNED = -psi -0.525;    // Heading

 while ((psiNED < -PI) || (psiNED > PI))
 {
   ROS_INFO("Entering while after atan2, understandable");
   // Adjust psiNED back within -PI and PI
   if (psiNED < -PI)
   {
     psiNED = psiNED + 2.0*PI;
   }
   if (psiNED > PI)
   {
     psiNED = psiNED - 2.0*PI;
   }
 }

}

std::string AMS_state_str;

void AMS_status (const std_msgs::String::ConstPtr& msg)
{
  AMS_state_str = msg->data;

}

void object_rec(const geometry_msgs::PointStamped::ConstPtr& msg)
{
  int i = 0;
       Object = msg->header.frame_id;  // Getting array of animal name. Based on on array location, the object is closer or farther from USV

  if (Object == "Blue Light")
  {
    Cod_Seq = "Blue";
    black = 0;
    cnt++;
  }
  else if (Object == "Red Light")
  {
    Cod_Seq = "Red";
    black = 0;
    cnt++;
  }
  else if (Object == "Green Light")
  {
    Cod_Seq= "Green";
    black = 0;
    cnt++;
  }
  else if (Object == "Black Light")
  {
    black++;
  }
} // END OF object_rec()

void CC_animals_ned_update(const geometry_msgs::PointStamped::ConstPtr& object)
{
    animal_qty = object->header.seq;
    //Animal_str = animal_qty + '0';
    Animal = object->header.frame_id;  // Getting array of animal names
}  // END OF CC_animals_ned_update()

int main(int argc, char **argv)
{
  ros::init(argc, argv, "talker");

  ros::NodeHandle n("~");

  ros::Publisher USV_latitude_pub = n.advertise<std_msgs::String>("USV_latitude", 1000);
  ros::Publisher USV_longitude_pub = n.advertise<std_msgs::String>("USV_longitude", 1000);
//  ros::Publisher UAV_latitude_pub = n.advertise<std_msgs::String>("UAV_latitude", 1000);
//  ros::Publisher UAV_longitude_pub = n.advertise<std_msgs::String>("UAV_longitude", 1000);
  ros::Publisher x_usv_NED_pub = n.advertise<std_msgs::String>("x_usv_NED", 1000);
  ros::Publisher y_usv_NED_pub = n.advertise<std_msgs::String>("y_usv_NED", 1000);
  ros::Publisher USV_heading_pub = n.advertise<std_msgs::String>("USV_heading", 1000);
  ros::Publisher AMS_Mode_pub = n.advertise<std_msgs::String>("AMS_Mode", 1000);
  ros::Publisher LightStack_pub = n.advertise<std_msgs::String>("Color_Light", 1000);
  ros::Publisher Animal_Color_pub = n.advertise<std_msgs::String>("Animal_Color_Light", 1000);
//  //Need below to pub to heart beat?
  ros::Publisher Server_IP_pub = n.advertise<std_msgs::String>("Tech_Sever_Ip", 1000);
  ros::Publisher Team_Info_pub = n.advertise<std_msgs::String>("Team_Info", 1000);
  ros::Publisher Port_pub = n.advertise<std_msgs::String>("Port", 1000);

  //  //need UAV
  //ros::Publisher UAV_latitude_pub = n.advertise<std_msgs::String>("USV_latitude", 1000);
  //ros::Publisher UAV_longitude_pub = n.advertise<std_msgs::String>("USV_longitude", 1000);
  ros::Subscriber nav_NED_sub = n.subscribe("/geonav_odom", 1000, pose_update);
  ros::Subscriber gpspos_sub = n.subscribe("/gps/fix", 1000, gps_processor);//subscribes to GPS position from outdoor gps

  ros::Subscriber imu_sub = n.subscribe("/imu/data", 1000, imu_processor);	// subscribes to IMU
  ros::Subscriber AMS_status_sub = n.subscribe("AMS_state", 1000, AMS_status);
  ros::Subscriber obj_rec_sub = n.subscribe("obj_rec", 1, object_rec);						//Obtains what object the camera recognise, pose of the object and order of recognition
  ros::Subscriber CC_animals_ned_sub = n.subscribe("CC_animals_ned", 1,CC_animals_ned_update );						//Obtains what is the current AMS state

  ros::Rate loop_rate(10);

  while (ros::ok())
  {
   std::stringstream ss1, ss2, ss3, ss4, ss5, ss6, ss7, ss8, ss9, ss10;

    std_msgs::String USV_latitude;
        ss1 << latitude_USV;
        USV_latitude.data = ss1.str();
    USV_latitude_pub.publish(USV_latitude);

    std_msgs::String USV_longitude;
        ss2 << longitude_USV;
        USV_longitude.data = ss2.str();
//        ROS_INFO("%s", USV_latitude.data.c_str());
//        ROS_INFO("%s", USV_longitude.data.c_str());
    USV_longitude_pub.publish(USV_longitude);

//    std_msgs::String UAV_latitude;
//            ss3 << latitude_UAV;
//            UAV_latitude.data = ss3.str();
//    UAV_latitude_pub.publish(UAV_latitude);

//        std_msgs::String UAV_longitude;
//            ss4 << longitude_UAV;
//            UAV_longitude.data = ss4.str();
//      UAV_longitude_pub.publish(UAV_longitude);

        std_msgs::String x_usv_NED;
            ss5 << x_NED_USV;
            x_usv_NED.data = ss5.str();

        std_msgs::String y_usv_NED;
            ss6 << y_NED_USV;
            y_usv_NED.data = ss6.str();
//            ROS_INFO("%s", AMS_Mode_pubx_usv_NED.data.c_str());
//            ROS_INFO("%s", y_usv_NED.data.c_str());
        x_usv_NED_pub.publish(x_usv_NED);
        y_usv_NED_pub.publish(y_usv_NED);

        std_msgs::String Mode;
            //ss7 << AMS_state_str;
        ss7 << AMS_state_str;
            Mode.data = ss7.str();
    //        ROS_INFO("%s", Mode.data.c_str());
        AMS_Mode_pub.publish(Mode);

        std_msgs::String USV_heading;
            ss8 << psiNED;
//            ROS_INFO("%f", psiNED);
            USV_heading.data = ss8.str();
            //ROS_INFO("%s", USV_heading.data.c_str());
        USV_heading_pub.publish(USV_heading);

        std_msgs::String Light;
            ss9 << Cod_Seq;
            Light.data = ss9.str();
            if (Cod_Seq != Cod_Seq_Temp)
            {
              LightStack_pub.publish(Light);
              Cod_Seq_Temp = Cod_Seq;
            }
        std_msgs::String AnimalC;
            ss10 << Animal;
            AnimalC.data = ss10.str();
            if (Animal != Animal_Temp)
             {
               Animal_Color_pub.publish(AnimalC);
               Animal_Temp = Animal;
             }



        ros::spinOnce();

        loop_rate.sleep();

  }


  return 0;
}
