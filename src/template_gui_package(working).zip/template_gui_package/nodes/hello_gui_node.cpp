#include <QApplication>
#include "hello_gui.h"
#include <stdlib.h> //

using namespace std;

int main(int argc, char *argv[])//
{
  ros::init(argc, argv, "hello_gui_node");
  QApplication a(argc, argv);

HelloGui w;
// set the window title as the node name
  w.setWindowTitle(QString::fromStdString(
                     ros::this_node::getName()));

  w.show();
  return a.exec();

}
