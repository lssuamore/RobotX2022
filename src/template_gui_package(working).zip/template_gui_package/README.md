# template_gui_package
A simple example/template for making ROS QT GUIs

## For a full explaination.
see this video:  https://youtu.be/Cg1DaNFnZyY
